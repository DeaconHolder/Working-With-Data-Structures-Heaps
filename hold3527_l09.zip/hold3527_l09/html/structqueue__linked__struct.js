var structqueue__linked__struct =
[
    [ "copy", "structqueue__linked__struct.htm#a31bbe024beb3fc1e811dc97481f87b43", null ],
    [ "count", "structqueue__linked__struct.htm#a7783e89b1bb34b45ec4b05154ae9abb7", null ],
    [ "destroy", "structqueue__linked__struct.htm#a31f87ac4a2b73e01fa58539211a763dc", null ],
    [ "front", "structqueue__linked__struct.htm#aeb5ef35a27fd3d145e9c1fabae8ec463", null ],
    [ "rear", "structqueue__linked__struct.htm#a53d614efd238500275cbd441eea90dea", null ],
    [ "to_string", "structqueue__linked__struct.htm#a453fe829417c84440e782b69d9c05676", null ]
];