var structstack__linked__struct =
[
    [ "copy", "structstack__linked__struct.htm#affb60009573deea35d60d58d43d1be37", null ],
    [ "destroy", "structstack__linked__struct.htm#acacaacb307d32b562c0b796c2e9fa80b", null ],
    [ "to_string", "structstack__linked__struct.htm#a27a55b71c51150d71d66eb870a1bcfb0", null ],
    [ "top", "structstack__linked__struct.htm#afeeabde61b9d27abac62c7d51c7abe2e", null ]
];