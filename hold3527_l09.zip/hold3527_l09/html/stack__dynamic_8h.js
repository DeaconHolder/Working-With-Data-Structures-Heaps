var stack__dynamic_8h =
[
    [ "stack_struct", "structstack__struct.htm", null ],
    [ "STACK_INIT", "stack__dynamic_8h.htm#a6d09b4e30b6162ac1e785978964f92fd", null ],
    [ "stack_count", "stack__dynamic_8h.htm#a0c3e86b586534d38a1e9afbeb3f74438", null ],
    [ "stack_destroy", "stack__dynamic_8h.htm#a0dcbfb3523dacfb27c9cc63f494c850b", null ],
    [ "stack_display", "stack__dynamic_8h.htm#a7b46a3ac88f9dc60a48f3d98c7fd995a", null ],
    [ "stack_empty", "stack__dynamic_8h.htm#a878b1105d2ab2d0584f03421f4602ee4", null ],
    [ "stack_full", "stack__dynamic_8h.htm#adb3f3a1298a28c801b9b19ba15522235", null ],
    [ "stack_initialize", "stack__dynamic_8h.htm#aa4fc2a59a6125df4d0fd55396924c819", null ],
    [ "stack_peek", "stack__dynamic_8h.htm#a4e4e49acb45b90219471c6316fdd88e4", null ],
    [ "stack_pop", "stack__dynamic_8h.htm#a9101c48dc4e67d681c2820453a150d19", null ],
    [ "stack_push", "stack__dynamic_8h.htm#a668d3be43bf7f98dcc211c4e46891b87", null ]
];