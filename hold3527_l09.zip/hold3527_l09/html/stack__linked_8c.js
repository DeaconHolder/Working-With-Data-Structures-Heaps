var stack__linked_8c =
[
    [ "stack_combine", "stack__linked_8c.htm#a23ff1679fb6ac5b4aa7e25dbf222d302", null ],
    [ "stack_copy", "stack__linked_8c.htm#a94e0e7b03fcabdc8e76d94584bf05df1", null ],
    [ "stack_destroy", "stack__linked_8c.htm#a9220fcdaae249dcb67fad04223655032", null ],
    [ "stack_empty", "stack__linked_8c.htm#adec72767412c8dfdc58b2ea00f3c7d3b", null ],
    [ "stack_full", "stack__linked_8c.htm#addcd3ba369d52741aaac815dcc023393", null ],
    [ "stack_initialize", "stack__linked_8c.htm#a7dc66ff96b875686ffe6f49664605b06", null ],
    [ "stack_peek", "stack__linked_8c.htm#acb7313149ea551e33a701f90e46561a4", null ],
    [ "stack_pop", "stack__linked_8c.htm#a868d3a3c8794bcb6bce151e5a33b7bac", null ],
    [ "stack_print", "stack__linked_8c.htm#a26f7348171c47eba2c61b691a5168938", null ],
    [ "stack_push", "stack__linked_8c.htm#a5f15ebddfb6fea9b74afdde462309df7", null ],
    [ "stack_split_alt", "stack__linked_8c.htm#a0d3383c1bc931fd90df8dc4078298678", null ]
];