var stack__linked_8h =
[
    [ "stack_node", "structstack__node.htm", "structstack__node" ],
    [ "stack_linked_struct", "structstack__linked__struct.htm", "structstack__linked__struct" ],
    [ "stack_node", "stack__linked_8h.htm#a1741765370e13f143f1ac2322fb0b399", null ],
    [ "stack_combine", "stack__linked_8h.htm#a23ff1679fb6ac5b4aa7e25dbf222d302", null ],
    [ "stack_copy", "stack__linked_8h.htm#a94e0e7b03fcabdc8e76d94584bf05df1", null ],
    [ "stack_destroy", "stack__linked_8h.htm#a9220fcdaae249dcb67fad04223655032", null ],
    [ "stack_empty", "stack__linked_8h.htm#adec72767412c8dfdc58b2ea00f3c7d3b", null ],
    [ "stack_full", "stack__linked_8h.htm#addcd3ba369d52741aaac815dcc023393", null ],
    [ "stack_initialize", "stack__linked_8h.htm#a7dc66ff96b875686ffe6f49664605b06", null ],
    [ "stack_peek", "stack__linked_8h.htm#acb7313149ea551e33a701f90e46561a4", null ],
    [ "stack_pop", "stack__linked_8h.htm#a868d3a3c8794bcb6bce151e5a33b7bac", null ],
    [ "stack_print", "stack__linked_8h.htm#a26f7348171c47eba2c61b691a5168938", null ],
    [ "stack_push", "stack__linked_8h.htm#a5f15ebddfb6fea9b74afdde462309df7", null ],
    [ "stack_split_alt", "stack__linked_8h.htm#a0d3383c1bc931fd90df8dc4078298678", null ]
];