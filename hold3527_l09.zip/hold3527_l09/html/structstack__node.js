var structstack__node =
[
    [ "item", "structstack__node.htm#aed7e70c48f6152515d8c38866a164608", null ],
    [ "next", "structstack__node.htm#af7b9916a0daa501304a00810a33a0b8c", null ]
];