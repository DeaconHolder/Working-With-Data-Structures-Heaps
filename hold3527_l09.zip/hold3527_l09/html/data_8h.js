var data_8h =
[
    [ "BOOLEAN", "data_8h.htm#a4b159ab7d9637f4ccd0d99f6e6aea738", null ],
    [ "data_ptr", "data_8h.htm#a8f1c9fafcef5a26e0b113b99d63365b1", null ],
    [ "boolean", "data_8h.htm#a7c6368b321bd9acd0149b030bb8275ed", null ],
    [ "data_compare", "data_8h.htm#a83e6d88f2abf7134939634275b438f24", null ],
    [ "data_copy", "data_8h.htm#ad574f4c71681dcf17fd9be852a76b685", null ],
    [ "data_free", "data_8h.htm#a3faff1037e15e8cb04dd463434b1ae6e", null ],
    [ "data_string", "data_8h.htm#af8a8245c1a16d3a8d8e196cc465d3f64", null ]
];