var structqueue__node =
[
    [ "item", "structqueue__node.htm#a1b032a5daa2ef479425c6b2001944128", null ],
    [ "next", "structqueue__node.htm#a565df498beea7adf6a5ff3a64ada8f78", null ]
];